import os


class Folder0(object):
    def __init__(self, foam):
        self.foam = foam
        self.foam.logger.info('create_object_mesh')
        self.file_content = ""
        self.folder_path = f"{self.foam.project_path}\\0"
        if not os.path.exists(self.folder_path):
            os.mkdir(self.folder_path)
        else:
            self.foam.logger.warning("The 0 file is already exist")

    def UDF_file(self):
        pass

    def T_file(self):
        self.file_content = ""
        self.file_content = self.foam.general_header(self.file_content, "volScalarField", "0", "T")
        self.file_content = self.foam.general_separator(self.file_content)
        self.set_dimensions(0, 0, 0, 1, 0, 0, 0)
        self.set_internal_field(300)
        bc_field = self.BoundaryField(self)
        bc_field.BC_zero_gradient()
        bc_field.BC_interface("interface_test")
        self.file_content = self.foam.general_separator(self.file_content)
        self.write_file("T")

    def set_dimensions(self, mass, length, time, temperature, quantity, current, Luminous_intensity):
        """
        :param mass: unit m
        :param length: unit kg
        :param time:  unit s
        :param temperature:  unit A
        :param quantity: unit K
        :param current: unit mol
        :param Luminous_intensity: unit cd
        :return:
        """
        self.file_content += f"""
dimensions      [ {mass} {length} {time} {temperature} {quantity} {current} {Luminous_intensity} ];
"""

    def set_internal_field(self, value, uniform=True):
        if uniform:
            if isinstance(value, int) or isinstance(value, float):
                self.file_content += f"""
internalField   uniform {value};
"""

    class BoundaryField(object):
        def __init__(self, f0):
            self.f0 = f0
            self.set_frame()

        def set_frame(self):
            self.f0.file_content += """

boundaryField
{

}
"""

        def BC_interface(self, bc_name, type="compressible::turbulentTemperatureCoupledBaffleMixed", value="$internalField", T_name="T", thickness=0, kappa=0):
            thermal_resistance = ""
            self.f0.file_content = self.f0.file_content[::-1].replace("}", "", 1)[::-1]
            if thickness:
                thermal_resistance = f"""
            thicknessLayers({thickness});
            kappalayers({kappa});
"""
            self.f0.file_content += f"""
    {bc_name}
    {{
            type            {type};
            value           {value};
            Tnbr            {T_name};
            {thermal_resistance}
    }}
"""
            self.f0.file_content += """
}
"""

        def BC_zero_gradient(self, bc_name=""" ".*" """):
            self.f0.file_content = self.f0.file_content[::-1].replace("}", "", 1)[::-1]
            self.f0.file_content += f"""
    {bc_name}
    {{
        type            zeroGradient;
    }}  
"""
            self.f0.file_content += """
}
"""

    def write_file(self, file_name):
        file = f"{self.folder_path}\\{file_name}"
        with open(file, 'w') as f:
            f.write(self.file_content)
        self.file_content = ""
