class FolderConstant(object):
    def __init__(self, foam):
        self.foam = foam
        self.foam.logger.info('create_object_mesh')